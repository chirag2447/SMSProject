
$(document).ready(function () {  

    $("#btnsend").click(function () {  
        send();  
    });  

    getmyfriends(); 

    
    setInterval(function () {  
        $.ajax({  
            type: "POST",  
            contentType: "application/json; charset=utf-8",  
            data: '{}',  
            url: "/Home/receive",  
            dataType: "json",  
            success: function (response) {  
                var data = $("#divmsg").html();  
                if(response != null){

                    $("#divmsg").html(data + "<br>Friend:" + response);  
                }
                  
            } 
        });  
    }, 1000);  

     
});

function getmyfriends()  
    {  
        $.ajax({  
            type: "POST",  
            url: "/Home/friendlist",  
            data: '{}',  
            dataType: "json",  
            success: function (r) {  
                var FriendList = $("#FriendList");  
                FriendList.empty().append('<option selected="selected" value="0">select</option>');  
                for (var i = 0; i <r.length; i++) {  
                    FriendList.append($("<option></option>").val(r[i]).html(r[i]));  
                }   
            },  
            error: function (r) {  
                alert("error");  
            }  
        });  
    }  

function send() {  
    var message = $("#txtmsg").val();  
    var friend = $("#FriendList").val();  
    var data = $("#divmsg").html();  
    $("#divmsg").html(data + "<br>Me:" + message);  
    $("#txtmsg").val("");  
    console.log("To: "+friend);
    console.log("Message: "+message);
    $.ajax({  
        type: "POST",   
        data: {"message":message,"friend":friend},  
        url: "/Home/sendmsg",  
        dataType: "json",  
        success: function (response) {  
            var data = $("#divmsg").html();  
            if(message == ""){
                $("#divmsg").html(data + "<br>Me :" + message);
            }  
        } 
    });  
} 