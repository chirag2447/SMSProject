using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft.Json;
using RabbitMQ.Models;

public class ChatController : Controller
{
    private readonly ConnectionFactory _factory;
    private const string QueueName = "chat_queue";
    private static List<ChatMessage> Messages = new List<ChatMessage>(); // Storing messages in memory for demonstration purpose

    public ChatController()
    {
        _factory = new ConnectionFactory
        {
            HostName = "localhost", // RabbitMQ server hostname
            UserName = "guest",
            Password = "guest"
        };
    }

    public ActionResult Person1()
    {
        return View(Messages);
    }

    public ActionResult Person2()
    {
        return View(Messages);
    }

    [HttpPost]
    public ActionResult SendMessage(string sender, string receiver, string message)
    {
        var chatMessage = new ChatMessage
        {
            Sender = sender,
            Receiver = receiver,
            Message = message,
            Timestamp = DateTime.Now
        };

        Messages.Add(chatMessage); // Add message to the list

        Console.WriteLine($"Message sent by {sender} to {receiver}: {message}"); // Log the message to the console

        using (var connection = _factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            channel.QueueDeclare(queue: QueueName, durable: false, exclusive: false, autoDelete: false, arguments: null);

            var jsonMessage = JsonConvert.SerializeObject(chatMessage);
            var body = Encoding.UTF8.GetBytes(jsonMessage);

            channel.BasicPublish(exchange: "", routingKey: QueueName, basicProperties: null, body: body);
        }

        // Determine the redirect based on the sender
        if (sender == "Person 1")
            return RedirectToAction("Person2");
        else if (sender == "Person 2")
            return RedirectToAction("Person1");
        else
            return RedirectToAction("Index"); // Redirect to some default page if sender is not recognized
    }
}
